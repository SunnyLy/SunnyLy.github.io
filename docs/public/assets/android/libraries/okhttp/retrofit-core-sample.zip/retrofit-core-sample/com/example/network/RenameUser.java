package com.example.network;

import com.google.gson.annotations.SerializedName;

public final class RenameUser {
    @SerializedName("display_name") public final String displayName;
    public RenameUser(String displayName) { this.displayName = displayName; }
}
