package com.example.network;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface UserApi {
    @GET("users/{id}")
    Call<ApiEnvelope<UserDto>> user(@Path("id") long id);

    @GET("users")
    Call<ApiEnvelope<List<UserDto>>> users();

    @POST("users/{id}/name")
    Call<ApiEnvelope<UserDto>> rename(@Path("id") long id, @Body RenameUser body);
}
