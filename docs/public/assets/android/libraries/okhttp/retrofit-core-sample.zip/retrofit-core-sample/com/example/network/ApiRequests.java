package com.example.network;

import java.io.IOException;
import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import com.google.gson.stream.MalformedJsonException;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public final class ApiRequests {
    private ApiRequests() {}

    // T 来自 UserApi 的具体声明，不能把它替换成 Object 或原始 Call。
    public static <T> Call<ApiEnvelope<T>> enqueue(
            Call<ApiEnvelope<T>> call, boolean requireData,
            Gson gson, ApiListener<T> listener) {
        call.enqueue(new Callback<ApiEnvelope<T>>() {
            @Override public void onResponse(Call<ApiEnvelope<T>> current,
                                              Response<ApiEnvelope<T>> response) {
                if (current.isCanceled()) {
                    listener.onError(new ApiError(ApiError.Kind.CANCELED,
                            null, null, "请求已取消", null));
                    return;
                }
                if (!response.isSuccessful()) {
                    // 非 2xx 不经过成功响应转换器；不能从 response.body() 取错误 JSON。
                    Integer businessCode = null;
                    String message = "HTTP " + response.code();
                    try (ResponseBody body = response.errorBody()) {
                        if (body != null) {
                            ErrorEnvelope error = gson.fromJson(body.charStream(), ErrorEnvelope.class);
                            if (error != null) {
                                businessCode = error.code;
                                if (error.message != null) message = error.message;
                            }
                        }
                    } catch (RuntimeException ignored) {
                        // 错误体可能是 HTML 或格式不符；仍保留首要的 HTTP 错误。
                    }
                    listener.onError(new ApiError(ApiError.Kind.HTTP,
                            response.code(), businessCode, message, null));
                    return;
                }
                ApiEnvelope<T> envelope = response.body();
                if (envelope == null || envelope.code == null) {
                    listener.onError(new ApiError(ApiError.Kind.PROTOCOL,
                            response.code(), null, "缺少业务响应或 code", null));
                    return;
                }
                if (envelope.code != ApiEnvelope.SUCCESS) {
                    listener.onError(new ApiError(ApiError.Kind.BUSINESS,
                            response.code(), envelope.code, envelope.message, null));
                    return;
                }
                if (requireData && envelope.data == null) {
                    listener.onError(new ApiError(ApiError.Kind.PROTOCOL,
                            response.code(), envelope.code, "成功响应缺少 data", null));
                    return;
                }
                listener.onSuccess(envelope.data);
            }

            @Override public void onFailure(Call<ApiEnvelope<T>> current, Throwable error) {
                ApiError.Kind kind;
                if (current.isCanceled()) kind = ApiError.Kind.CANCELED;
                else if (error instanceof JsonParseException || error instanceof MalformedJsonException)
                    kind = ApiError.Kind.CONVERSION;
                else if (error instanceof IOException) kind = ApiError.Kind.NETWORK;
                else kind = ApiError.Kind.UNKNOWN;
                listener.onError(new ApiError(kind, null, null, error.getMessage(), error));
            }
        });
        return call;
    }

    // 错误体只关心 code/message，不假定它与成功响应的 data 类型一致。
    private static final class ErrorEnvelope {
        @com.google.gson.annotations.SerializedName("code") Integer code;
        @com.google.gson.annotations.SerializedName("message") String message;
    }
}
