package com.example.network;

import java.util.List;
import retrofit2.Call;

public final class UserRepository {
    private final Network network;
    public UserRepository(Network network) { this.network = network; }

    public Call<ApiEnvelope<UserDto>> user(long id, ApiListener<UserDto> listener) {
        return ApiRequests.enqueue(network.users.user(id), true, network.gson, listener);
    }

    public Call<ApiEnvelope<List<UserDto>>> users(ApiListener<List<UserDto>> listener) {
        return ApiRequests.enqueue(network.users.users(), true, network.gson, listener);
    }
}
