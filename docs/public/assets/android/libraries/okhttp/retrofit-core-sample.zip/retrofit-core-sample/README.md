# OkHttp + Retrofit core example

This is source to integrate into an existing Android app, not a standalone Gradle project.

1. Add the dependencies from dependencies.gradle.kts to the app module. OkHttp requires Android API 21+; use Java 8 language support for the lambdas and try-with-resources.
2. Copy com/example/network into app/src/main/java. Merge AndroidManifest.fragment.xml into the existing manifest. If an Application already exists, merge the initialization rather than replacing it.
3. Replace https://api.example.com/v1/ in StudyApplication with your HTTPS API URL. Keep the trailing slash. The sample backend contract is GET users/{id}, GET users, POST users/{id}/name, with {code:0,message:"OK",data:...}. Actual JSON uses proper quoted field names.
4. Open UserActivity from your app. It is not exported; no launcher intent is supplied by this sample. It loads user 7 and cancels the call when destroyed.
5. StudyApplication owns one Network and a background callback executor. UI callbacks explicitly switch to the main thread. For retained requests, move ownership and state into an appropriate ViewModel.
6. Error classification and business SUCCESS belong to this example's contract. Validate DTO fields when mapping into domain objects. ApiRequests checks only envelope code/data, not every UserDto field.
7. Large downloads, large error bodies, authentication refresh, persistent offline state, and release shrinking need project-specific handling. This example has no automatic business retry.

Sources and explanation: docs/android/libraries/okhttp.md.
