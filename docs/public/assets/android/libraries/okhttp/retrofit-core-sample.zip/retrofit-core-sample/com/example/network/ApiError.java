package com.example.network;

public final class ApiError {
    public enum Kind { HTTP, BUSINESS, PROTOCOL, NETWORK, CONVERSION, CANCELED, UNKNOWN }
    public final Kind kind;
    public final Integer httpCode;     // 当前分支拿不到 Retrofit Response 时为 null。
    public final Integer businessCode; // 未拿到有效业务 Code 时为 null。
    public final String message;
    public final Throwable cause;

    public ApiError(Kind kind, Integer httpCode, Integer businessCode,
                    String message, Throwable cause) {
        this.kind = kind;
        this.httpCode = httpCode;
        this.businessCode = businessCode;
        this.message = message;
        this.cause = cause;
    }
}
