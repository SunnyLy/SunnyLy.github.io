package com.example.network;

import android.app.Application;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class StudyApplication extends Application {
    private UserRepository users;
    private final ExecutorService callbacks = Executors.newSingleThreadExecutor();

    @Override public void onCreate() {
        super.onCreate();
        Network network = new Network("https://api.example.com/v1/", getCacheDir(),
                callbacks); // 业务响应处理放后台；页面显式切主线程。
        users = new UserRepository(network);
    }

    public UserRepository users() { return users; }
}
