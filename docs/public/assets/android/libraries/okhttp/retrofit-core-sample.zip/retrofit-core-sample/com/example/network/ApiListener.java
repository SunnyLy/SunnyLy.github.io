package com.example.network;

public interface ApiListener<T> {
    void onSuccess(T data);
    void onError(ApiError error);
}
