package com.example.network;

import com.google.gson.annotations.SerializedName;

public final class UserDto {
    @SerializedName("id") public Long id;
    @SerializedName("display_name") public String displayName;
}
