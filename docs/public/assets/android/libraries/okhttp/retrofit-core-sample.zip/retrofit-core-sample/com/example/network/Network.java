package com.example.network;

import java.io.File;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.Strictness;
import okhttp3.Cache;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public final class Network {
    public final Gson gson;
    public final UserApi users;

    public Network(String baseUrl, File appCacheDir, Executor callbackExecutor) {
        gson = new GsonBuilder().setStrictness(Strictness.STRICT).create();
        OkHttpClient http = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .callTimeout(30, TimeUnit.SECONDS)
                .cache(new Cache(new File(appCacheDir, "retrofit-http"), 20L * 1024 * 1024))
                .build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(baseUrl) // 例如 https://api.example.com/v1/，末尾必须有 /。
                .client(http)    // Retrofit 的 HTTP 调用最终交给这个共享 Client。
                .addConverterFactory(GsonConverterFactory.create(gson))
                .callbackExecutor(callbackExecutor)
                .build();
        users = retrofit.create(UserApi.class);
    }
}
