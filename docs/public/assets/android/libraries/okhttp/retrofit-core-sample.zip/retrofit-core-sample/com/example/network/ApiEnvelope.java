package com.example.network;

import com.google.gson.annotations.SerializedName;

public final class ApiEnvelope<T> {
    // 本示例与服务端约定 0 为业务成功；不是 HTTP 状态码。
    public static final int SUCCESS = 0;
    @SerializedName("code") public Integer code;
    @SerializedName("message") public String message;
    @SerializedName("data") public T data;
}
