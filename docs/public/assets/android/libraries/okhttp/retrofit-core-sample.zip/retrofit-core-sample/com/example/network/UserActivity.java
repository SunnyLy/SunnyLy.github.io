package com.example.network;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import retrofit2.Call;

public final class UserActivity extends Activity {
    private Call<ApiEnvelope<UserDto>> inFlight;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        TextView text = new TextView(this);
        setContentView(text);
        text.setText("加载中");
        UserRepository repository = ((StudyApplication) getApplication()).users();
        inFlight = repository.user(7, new ApiListener<UserDto>() {
            @Override public void onSuccess(UserDto user) {
                runOnUiThread(() -> {
                    if (!canDisplay()) return;
                    // Gson 反射不会替你检查业务必填字段。
                    if (user.id == null || user.displayName == null) {
                        text.setText("数据缺少必要字段");
                        return;
                    }
                    text.setText(user.displayName);
                });
            }
            @Override public void onError(ApiError error) {
                runOnUiThread(() -> {
                    if (!canDisplay() || error.kind == ApiError.Kind.CANCELED) return;
                    text.setText("请求失败：" + error.kind);
                });
            }
        });
    }

    private boolean canDisplay() {
        return !isFinishing() && !isDestroyed();
    }

    @Override protected void onDestroy() {
        if (inFlight != null) inFlight.cancel();
        super.onDestroy();
    }
}
